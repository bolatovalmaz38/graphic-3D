#include <QApplication> 
#include <QMainWindow>
#include <QVBoxLayout>
#include <QAction>
#include <QMenuBar>
#include <QMessageBox>
#include "scene3D.h" 
 
int main(int argc, char** argv) { 
	QApplication app(argc, argv); // создаём приложение, инициализация оконной системы

	
	Scene3D scene1;
	if(scene1.parse_command_line(argc, argv))
	{
		QMessageBox::warning (0, "Wrong input arguments!", 
                            "Wrong input arguments!");
     		 return -1;
	}
	//Scene3D scene1; // создаём виджет класса Scene3D
	scene1.setWindowTitle("Graph 3D"); // название окна   
	scene1.resize(1000, 1000);  // размеры (nWidth, nHeight) окна  
	scene1.show(); // изобразить виджет
	// scene1.showFullScreen();
	// scene1.showMaximized();  
 
	return app.exec();
} 
