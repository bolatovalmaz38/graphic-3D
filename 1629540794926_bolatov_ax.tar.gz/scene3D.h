#ifndef SCENE3D_H 
#define SCENE3D_H
 
#include <QGLWidget> 

class Scene3D : public QGLWidget { 
   private: 
	GLfloat xRot; 
	GLfloat yRot;   
	GLfloat zRot;
	GLfloat zTra; 
	GLfloat nSca; 

	QPoint ptrMousePosition;  

	void scale_plus();     
	void scale_minus();     
	void rotate_up();     
	void rotate_down();    
	void rotate_left();    
	void rotate_right();   
	void translate_down(); 
	void translate_up();       
	void defaultScene();        

	void PaintEvent();

	void getVertexArray(); 
	void getColorArray();  
	void getIndexArray();       
	void drawFigure();    
	
	const char *f_name, *f_name_2 = "3 programm";
	double max;
	double error1, error2;
	double a, b;
	double c, d;
	int n, N, m, M, k;
  	int func_id;
	int outrage;
	int mode;
	void rebutt(int);

	double *x = NULL, *y = NULL, *xxx = NULL;
  	double *f_y = NULL, *f_x = NULL;
  	double *cx = NULL, *cy = NULL, *d2 = NULL; 
	double *xx = NULL, *yy = NULL, *yyy = NULL;
  	double *f_y2 = NULL, *f_x2 = NULL;
  	double *c2x = NULL, *c2y = NULL, *dx = NULL, *dy = NULL, *H = NULL; 	
  	double *xz = NULL, *yxz = NULL, *ym1 = NULL, *yym1 = NULL; 	
  	double *ym2 = NULL, *yym2 = NULL; 	
	double (*f2) (double, double);
	double (*f1) (double);
	double (*df_f) (double);
 
   protected:
	void initializeGL();                      
	void resizeGL(int nWidth, int nHeight);  
	void paintGL();                            

	void mousePressEvent(QMouseEvent* pe);   
	void mouseMoveEvent(QMouseEvent* pe);  
	
	void wheelEvent(QWheelEvent* pe);         
	void keyPressEvent(QKeyEvent* pe);      
 
   public: 
	Scene3D(QWidget* parent = 0); 
	~Scene3D ();
	int parse_command_line(int argc, char *argv[]);
	void Input_08(void);
  	void Calc_08(void);
  	void Coeff_08(double A, double B, int l, int o, double *x, double *y, double *f_y, double *c);
  	double Quad(double x);
  	void Input_30(void);
  	void Calc_30(void);
  	void Coeff_30(int n, double *x2, double *f_x2, double *c2);
  	double Mid(double A, double B, int l, int o, int i, double *x, double *y, double *f_y);
	double value(int l, double *x, double t, double *cc, int fl);//, int fll);
	void drawFunc();
   public slots:
  	void change_func ();	
	void change_mode ();	
	void increase_n ();	
	void reduce_n ();	
	void increase_m ();
	void zoom_in();
	void zoom_out();	
	void reduce_m ();		
	void plus ();	
	void minus ();	
}; 
#endif
