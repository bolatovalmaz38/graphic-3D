﻿#include <QtGui>     
#include <iostream>
#include <math.h>    
#include "scene3D.h"  
#include <stdlib.h>
#include <limits>
#include <cfloat>
using namespace std;
#define DEFAULT_A -10
#define DEFAULT_B 10
#define DEFAULT_N 11
#define DEFAULT_NN 22
#define DEFAULT_C -10
#define DEFAULT_D 10
#define DEFAULT_M 11
#define DEFAULT_MM 22
double delta_x, delta_y, vh, vg;
static double f_0 (double x) {return 1 + 0 * x;}
static double f_1 (double x) {return x;}
static double f_2 (double x) {return x * x;}
static double f_3 (double x) {return x * x * x;}
static double f_4 (double x) {return x * x * x * x;}
static double f_5 (double x) {return exp(x);}
static double f_6 (double x) {return 1 / (25 * x * x + 1);}
static double ff_0 (double x, double y) {return 2 + 0 * x * y;}
static double ff_1 (double x, double y) {return x + y;}
static double ff_2 (double x, double y) {return x * x + y * y;}
static double ff_3 (double x, double y) {return x * x * x + y * y * y;}
static double ff_4 (double x, double y) {return x * x * x * x + y * y * y * y;}
static double ff_5 (double x, double y) {return exp(x) + exp(y);}
static double ff_6 (double x, double y) {return 1 / (25 * x * x + 1) + 1 / (25 * y * y + 1);}
static double df_0 (double x) {return 0 + 0 * x;}
static double df_1 (double x) {return 1 + 0 * x;}
static double df_2 (double x) {return 2 * x;}
static double df_3 (double x) {return 3 * x * x;}
static double df_4 (double x) {return 4 * x * x * x;}
static double df_5 (double x) {return exp(x);}
static double df_6 (double x) {return -50 * x / (25 * x * x + 1) / (25 * x * x + 1);}
void Scene3D:: rebutt(int k)
{
	func_id = k;
	func_id--;
	change_func();
}
int Scene3D::parse_command_line (int argc, char *argv[])
{
	if((argc > 1 && argc < 8) || argc > 8)
	{
		printf("!!!!!!!!!!!owibka!!!!!!!!!!!!!\n");
		return -1;
	}

  if (argc == 8 && (sscanf (argv[1], "%lf", &a) != 1
      || sscanf (argv[2], "%lf", &b) != 1
      || sscanf (argv[3], "%lf", &c) != 1
      || sscanf (argv[4], "%lf", &d) != 1
      || sscanf (argv[5], "%d", &n) != 1
      || sscanf (argv[6], "%d", &m) != 1
      || sscanf (argv[7], "%d", &k) != 1
      || b - a < 1.e-6
      || d - c < 1.e-6
      || m <= 2
      || n <= 2
      || k > 6
      || k < 0)) return -2;
	printf("normalno vse\n");
  if(argc == 8){
	N = n + n;
	M = m + m;
	rebutt(k);
  }
  return 0;
}
Scene3D::Scene3D(QWidget* parent/* = 0 */) : QGLWidget(parent) { 
	xRot=-90; yRot=0; zRot=0; zTra=0; nSca=1;

	a = DEFAULT_A;
	b = DEFAULT_B;
	n = DEFAULT_N;
	N = DEFAULT_NN;

	c = DEFAULT_C;
	d = DEFAULT_D;
	m = DEFAULT_M;
	M = DEFAULT_MM;

	func_id = 0;
	max = 0.0;
	mode = 0;
	outrage = 0;
	error1 = 0.0;
	error2 = 0.0;
	change_func ();
} 

Scene3D::~Scene3D () {	
}
void Scene3D::change_func ()
{
  func_id = (func_id + 1) % 7;
  switch (func_id)
    {
      case 0:
        f_name = "f (x) = 1";
        f2 = ff_0;
	f1 = f_0;
	df_f = df_0;
        break;
      case 1:
        f_name = "f (x) = x";
        f2 = ff_1;
	f1 = f_1;
	df_f = df_1;
        break;
      case 2:
        f_name = "f (x) = x * x";
        f2 = ff_2;
	f1 = f_2;
	df_f = df_2;
        break;
      case 3:
        f_name = "f (x) = x * x * x";
        f2 = ff_3;
	f1 = f_3;
	df_f = df_3;
        break;
      case 4:
        f_name = "f (x) = x * x * x * x";
        f2 = ff_4;
	f1 = f_4;
	df_f = df_4;
        break;
      case 5:
        f_name = "f (x) = EXP(x)";
        f2 = ff_5;
	f1 = f_5;
	df_f = df_5;
        break;
      case 6:
        f_name = "f (x) = 1 / (25 * x * x + 1)";
        f2 = ff_6;
	f1 = f_6;
	df_f = df_6;
        break;
    }
  update ();
}
void Scene3D::Input_08(void)
{
	int i, j1 = N / 2, j2 = M / 2;
	double h1, h2;

	h1 = (b - a)/(N - 1);
	for (i = 0; i < N; i++){
		y[i] = a + i * h1;
		f_x[i] = f1(y[i]);	
	}
	f_x[j1] += 0.1 * outrage * max;
	h1 = (b - a)/(n - 1);
	for (i = 0; i < n; i++) x[i] = a + i * h1;

	h2 = (d - c)/(M - 1);
	for (i = 0; i < M; i++){
		yy[i] = c + i * h2;
		f_y[i] = f1(yy[i]);	
	}
	f_y[j2] += 0.1 * outrage * max;
	h2 = (d - c)/(m - 1);
	for (i = 0; i < m; i++) xx[i] = c + i * h2;
}
void Scene3D::Calc_08(void)
{
	x = (double*)malloc(n * sizeof(double));
	y = (double*)malloc(N * sizeof(double));
	f_x = (double*)malloc(N * sizeof(double));
	xx = (double*)malloc(m * sizeof(double));
	yy = (double*)malloc(M * sizeof(double));
	f_y = (double*)malloc(M * sizeof(double));
	Input_08();
	Coeff_08(a, b, n, N, x, y, f_x, cx);	
	Coeff_08(c, d, m, M, xx, yy, f_y, cy);
	free(y);
	free(f_x);
	free(yy);
	free(f_y);
}
void Scene3D::Coeff_08(double A, double B, int l, int o, double *x, double *y, double *f, double *cc)
{
	int i, p = 0;
	double hf, h = (B - A) / (l - 1), hh = h / 3.0, hhh = hh / 2.0, r;
	H = (double*)malloc(4*l * sizeof(double));
	H[0] = hh;
	H[l - 1] = hh;
	H[l] = 0.5;
	H[3 * l - 2] = hhh;
	h = (B - A) / (o - 1);
	while (p < o && y[p+1] < x[1]) p++;
	if (p == o) p = 0;
	hf = f[p+1] - f[p];
	r = -1 * (hf / h * (x[1] - y[p + 1]) + f[p + 1]) * f_2(x[1]) / 2.0 - f[0] * x[0] * (x[0] / 2.0 - x[1]);
	for (i = 0; i < p; i++)
		r += (f[i + 1] - f[i]) / h * (f_2(y[i]) * (y[i] / 3.0 - x[1]) - f_2(y[i+1]) * (y[i + 1] / 3.0 - x[1])) / 2.0;
	r = (r + hf / h * (2.0 * f_3(x[1]) / 3.0 + f_2(y[p]) * (y[p] / 3.0 - x[1])) / 2.0) / (x[0] - x[1]);
	H[3 * l] = r;
	for (i = 1; i < l - 1; i++){
		H[i] = hh * 2;
		H[l + i] = hhh;
		H[2 * l + i - 1] = hhh;
		H[3 * l + i] = Mid(A, B, l, o, i, x, y, f);
	}
	p = o-2;
	while (p >= 0 && y[p] > x[l-2]) p--;
	if (p < 0) p = o;
	hf = f[p+1] - f[p];
	r = x[l - 1] * (x[l - 1]/2.0 - x[l - 2]) * f[o - 1];
	r += (hf / h * (x[l - 2] - y[p + 1]) + f[p + 1]) * x[l - 2] * x[l - 2] / 2.0;
	r += hf / h * (y[p + 1] * y[p + 1] * (x[l - 2] - y[p + 1] / 3.0) - 2.0 * x[l - 2] * x[l - 2] * x[l - 2] / 3.0) / 2.0;
	for (i = p + 1; i < o - 1; i++)
		r += (f[i + 1] - f[i]) / h * (f_2(y[i]) * (y[i]/3.0 - x[l - 2]) - f_2(y[i + 1]) * (y[i + 1] / 3.0 - x[l - 2])) / 2.0;
	r /= (x[l - 1] - x[l - 2]);
	H[4 * l - 1] = r;
	for (i = 1; i < l-1; i++){
		H[i] -= H[2 * l + i - 1] * H[l + i - 1];
		H[l + i] /= H[i];
	}
	H[l - 1] -= H[3 * l - 2] * H[2 * l - 2];
	cc[0] = H[3 * l] / H[0];
	for (i = 1; i < l; i++){
		cc[i] = (H[3 * l + i] - H[2 * l + i - 1] * cc[i - 1]) / H[i];
	}	
	for (i = l - 2; i >= 0; i--){
		cc[i] -= H[l + i] * cc[i + 1];
	}
	free(H);
}
double Scene3D::Mid(double A, double B, int l, int o, int i, double *x, double *y, double *f_y)
{
	int j, k, p, q;
	double r1 = 0, r2 = 0;
	double h = (B - A) / (o - 1), hh1, hh2, hh3, hh = (B-A) / (l-1);
	if (i > 3)	
		k = 2*i-3;
	else
		k = 0;
	while (k < o && y[k] <= x[i - 1]) k++;
	if (k == o) k = 0;
	else k--;
	
	p = k;
	while (p < o && y[p] <= x[i]) p++;
	if (p == o) p = 0;
	else p--; 	

	q = p;
	while (q < o && y[q] < x[i + 1]) q++;
	if (q == o) q = N-2;
	else q--;
	hh1 = f_y[p+1] - f_y[p];
	hh2 = f_y[k+1] - f_y[k];
	hh3 = f_y[q+1] - f_y[q];
	r1 = (hh1 / h * (x[i] - y[p + 1]) + f_y[p + 1]) * x[i] * (x[i]/2.0 - x[i - 1]);
	r1 += f_2(x[i - 1]) * (hh2 / h * (x[i - 1] - y[k + 1]) + f_y[k + 1])/2.0;
	r1 -= hh2 / h * (f_2(y[k + 1]) * (y[k + 1]/3.0 - x[i - 1]) + 2.0 * f_3(x[i - 1]) / 3.0)/2.0;
	for (j = k + 1; j < p; j++)
	r1 += (f_y[j + 1] - f_y[j]) / h * (f_2(y[j]) * (y[j]/3.0 - x[i - 1]) - f_2(y[j + 1]) * (y[j + 1]/3.0 - x[i - 1]))/2.0;
	r1 += hh1 / h * (f_2(y[p]) * (y[p]/3.0 - x[i - 1]) - f_2(x[i]) * (x[i]/3.0 - x[i - 1]))/2.0;
	r1 /= hh;
	r2 = (hh3 / h * (x[i + 1] - y[q + 1]) + f_y[q + 1]) * (-1) * f_2(x[i + 1]) / 2.0;
	r2 -= (hh1 / h * (x[i] - y[p + 1]) + f_y[p + 1]) * x[i] * (x[i]/2.0 - x[i + 1]);
	r2 += hh1 / h * (f_2(x[i]) * (x[i]/3.0 - x[i + 1]) - f_2(y[p + 1]) * (y[p + 1] / 3.0 - x[i + 1]))/2.0;
	for (j = p + 1; j < q; j++)
	r2 += (f_y[j + 1] - f_y[j]) / h * (f_2(y[j]) * (y[j] / 3.0 - x[i + 1]) - f_2(y[j + 1]) * (y[j + 1]/3.0 - x[i + 1]))/2.0;
	r2 += hh3 / h * (2.0 * f_3(x[i + 1]) / 3.0 + f_2(y[q]) * (y[q]/3.0 - x[i + 1]))/2.0;
	r2 /= -hh;
	return r1 + r2;
}

void Scene3D::Input_30(void)
{
	int i;
	double h;
	int j1 = n / 2, j2 = m / 2;
	h = (b - a)/(n - 1);		
	for (i = 0; i < n; i++){
		xxx[i] = a + i * h;
		f_x2[i] = f1(xxx[i]);
	}
	f_x2[j1] += 0.1 * outrage * max;

	h = (d - c)/(m - 1);
	for (i = 0; i < m; i++){
		yyy[i] = c + i * h;
		f_y2[i] = f1(yyy[i]);
	}
	f_y2[j2] += 0.1 * outrage * max;
}
void Scene3D::Calc_30(void)
{
	xxx = (double*)malloc(n * sizeof(double));
	f_x2 = (double*)malloc(n * sizeof(double));
	
	yyy = (double*)malloc(m * sizeof(double));
	f_y2 = (double*)malloc(m * sizeof(double));
	Input_30();
	Coeff_30(n, xxx, f_x2, c2x);
	Coeff_30(m, yyy, f_y2, c2y);
	free(f_x2);
	free(f_y2);
}
double Scene3D::Quad(double x) {return (f1(x + 2 * 1e-8) - 2 * f1(x) + f1(x - 2 * 1e-8))/ f_2(1e-8) / 4;}
void Scene3D::Coeff_30(int n, double *x2, double *f_x2, double *c2)
{
	int i, j;
	double t1, t2, h, hh;
	d2 = (double*)malloc(n * sizeof(double));
	h = x2[1] - x2[0];
	hh = x2[n-1] - x2[n-2];
	for (i = 1; i < n - 1; i++){
		t1 = (f_x2[i] - f_x2[i - 1]) / h;
		t2 = (f_x2[i + 1] - f_x2[i]) / h;
		if (t1 * t2 > 0){ 
			if (t1 > 0)
				d2[i] =  1; 
			else
				d2[i] = -1;
			if (fabs(t1) > fabs(t2)) 
				d2[i] *= fabs(t2);
			else
				d2[i] *= fabs(t1);
		}
		else d2[i] = 0.0;
	}
	t1 = (f_x2[1] - f_x2[0]) / h;
	t2 = (f_x2[n - 1] - f_x2[n - 2]) / hh;
	d2[0] = 1.5 * t1 - d2[1] / 2.0 - Quad(x2[0]) * h / 4;
	d2[n - 1] = 1.5 * t2 - d2[n - 2] / 2.0 + Quad(x2[n - 1]) * h / 4;
	j = 0;
	for (i = 0; i < n - 1; i++, j += 4){
		c2[j + 0] = f_x2[i];
		c2[j + 1] = d2[i];
		if (i < n-2){
			t1 = (f_x2[i + 1] - f_x2[i]) / h;
			c2[j + 2] = (3 * t1 - 2 * d2[i] - d2[i + 1]) / h;
			c2[j + 3] = (d2[i] + d2[i + 1] - 2 * t1) / f_2(h);
		}		
		else{
			t1 = (f_x2[i + 1] - f_x2[i]) / hh;				
			c2[j + 2] = (3 * t1 - 2 * d2[i] - d2[i + 1]) / hh;
			c2[j + 3] = (d2[i] + d2[i + 1] - 2 * t1) / f_2(hh);
		}		
	}
	free(d2);
}
void Scene3D::PaintEvent(){
	double x11, x1 = 0, x2 = 0;
	double y1 = 0, y2 = 0;
	double z1 = 0, z3 = 0, delta_z;
	double max_z, min_z;
	double x_mid, y_mid;
	double h = (b - a) / (n - 1);
	double g = (d - c) / (m - 1), *z, *z2, *Z;
	int i, j, nn = 2, nnn = 2;
	vh = (b-a) / (n-1);
	vg = (d-c) / (m-1);
	error1 = 0.0;
	error2 = 0.0;
	delta_x = (b - a) / width ();
	delta_y = (d - c) / depth ();
	xz = NULL;
	yxz = NULL;
	ym1 = NULL;
	ym2 = NULL;
	yym1 = NULL;
	yym2 = NULL;
	x_mid = a + n / 2 * h;
	y_mid = c + m / 2 * g;
	max_z = 0.0; min_z = 0.0;
	x1 = a;
	for (x2 = x1 + delta_x; x2 - b < 1.0e-6; x2 += delta_x) {
		y1 = c;
		z1 = f2(x1, y1);
		if (z1 > max_z) max_z = z1;
		if (z1 < min_z) min_z = z1;
		for (y2 = y1 + delta_y; y2 - d < 1.0e-6; y2 += delta_y) {
			z3 = f2(x1, y2);
			if (fabs (x2 - x_mid) < 1.0e-10 &&
			    fabs (y2 - y_mid) < 1.0e-10)
				z3 += 0.1 * outrage * max;
			if (z3 > max_z) max_z = z3;
			if (z3 < min_z) min_z = z3;
			y1 = y2; z1 = z3;
		}
		y2 = d;
		z3 = f2(x1, y2);
		if (z3 > max_z) max_z = z3;
		if (z3 < min_z) min_z = z3;
		x1 = x2;
	}
	x2 = b; y2 = d;
	z3 = f2(x2, y2);
	if (z3 > max_z) max_z = z3;
	if (z3 < min_z) min_z = z3;
	max = (fabs (max_z) > fabs (min_z)) ? fabs (max_z) : fabs (min_z);
	delta_z = 0.01 * (max_z - min_z);
	max_z += delta_z;
	min_z -= delta_z;	
	glLineWidth(3.0f); 
	qglColor("red"); 
	glBegin(GL_LINES); //Ox
		glVertex3f(10 * a, 0.0f, 0.0f); 
		glVertex3f(10 * b, 0.0f, 0.0f); 
	glEnd();
	QColor halfGreen(0, 128, 0, 255);
	qglColor(halfGreen);
	glBegin(GL_LINES); //Oy
		glVertex3f(0.0f, 10 * c, 0.0f);
		glVertex3f(0.0f, 10 * d, 0.0f);
	glEnd ();
	qglColor("blue");
	glBegin (GL_LINES); //Oz
		glVertex3f(0.0f, 0.0f, 2 * min_z);
		glVertex3f(0.0f, 0.0f, 2 * max_z);
	glEnd();
	delta_x = (b - a) / width ();
	//if(n > width())
	//	delta_x = (b - a) / (n - 1);
	delta_y = (d - c) / width ();
	//if(m > depth())
	//	delta_y = (d - c) / (m - 1);
	for (x11 = a + delta_x; x11 - b < 1.e-6; x11 += delta_x) nn++;
	for (x11 = c + delta_y; x11 - d < 1.e-6; x11 += delta_y) nnn++;
	yxz = (double*)malloc(nnn * sizeof(double));   		   		
	xz = (double*)malloc(nn * sizeof(double));	
	xz[0] = a;
	yxz[0] = c;
	for (i = 0; i < nn - 2; i++) {
		xz[i+1] = xz[i] + delta_x;
	}
	for (i = 0; i < nnn - 2; i++) {		
		yxz[i+1] = yxz[i] + delta_y;
	}		
	xz[nn-1] = b;
	yxz[nnn-1] = d;
	Z = (double*)malloc(nn * nnn * sizeof(double));		
	for (i = 0; i < nn; i++) {
		for (j = 0; j < nnn; j++)		
			Z[i*nnn + j] = f2(xz[i], yxz[j]);
	}			
	if (mode == 0){
		z = (double*)malloc(nn * nnn * sizeof(double));	
		cx = (double*)malloc(n * sizeof(double));
		cy = (double*)malloc(m * sizeof(double));
		Calc_08();
		ym1 = (double*)malloc(nn * sizeof(double));
		yym1 = (double*)malloc(nnn * sizeof(double));
		glLineWidth(0.6f);
		qglColor ("green");
		glBegin(GL_LINES);
		for (i = 0; i < nn; i++) {
			ym1[i] = value(n, x, xz[i], cx, 1);
		}
		for (i = 0; i < nnn; i++) {
			yym1[i] = value(m, xx, yxz[i], cy, 1);
		}
		for (i = 0; i < nn; i++) {		
			z[i*nnn] = ym1[i] + yym1[0];
			for (j = 1; j < nnn; j++) {
				z[i*nnn + j] = ym1[i] + yym1[j];
				glVertex3f (xz[i], yxz[j-1], z[i*nnn+j-1]); 
				glVertex3f (xz[i], yxz[j], z[i*nnn+j]);
			}
		}
		for (i = 0; i < nn; i++){
			for (j = 0; j < nnn; j++) {
				z1 = fabs (Z[i*nnn+j] - z[i*nnn + j]);
				if (z1 > error1) error1 = z1;
			}
		}
		drawFunc();
		glEnd();
		free(x);
		free(xx);
		free (cx);
		free (cy);
		free (z);
		free (ym1);
		free (yym1);
	}
	else if (mode == 1){
		z2 = (double*)malloc(nn * nnn * sizeof(double));	
		c2x = (double*)malloc(4*(n-1) * sizeof(double));
		c2y = (double*)malloc(4*(m-1) * sizeof(double));
		Calc_30();
		ym2 = (double*)malloc(nn * sizeof(double));
		yym2 = (double*)malloc(nnn * sizeof(double));
		glLineWidth(0.6f);
		qglColor ("blue");
		glBegin(GL_LINES);
		for (i = 0; i < nn; i++){
			ym2[i] = value(n, xxx, xz[i], c2x, 2);
		}
		for (i = 0; i < nnn; i++){
			yym2[i] = value(m, yyy, yxz[i], c2y, 2);
		}
		for (i = 0; i < nn; i++){
			z2[i*nnn] = ym2[i] + yym2[0];
			for (j = 1; j < nnn; j++) {
				z2[i*nnn + j] = ym2[i] + yym2[j];
				glVertex3f (xz[i], yxz[j-1], z2[i*nnn+j-1]); 
				glVertex3f (xz[i], yxz[j], z2[i*nnn+j]);
			}
		}
		for (i = 0; i < nn; i++){
			for (j = 0; j < nnn; j++) {
				z1 = fabs(Z[i*nnn+j] - z2[i*nnn + j]);
				if (z1 > error2) error2 = z1;
			}
		}
		drawFunc();	
		glEnd();
		free(xxx);
		free(yyy);		
		free(c2x);
		free(c2y);		
		free(z2);
		free(ym2);
		free(yym2);
	}	
	else if (mode == 2){
		z = (double*)malloc(nn * nnn * sizeof(double));	
		z2 = (double*)malloc(nn * nnn * sizeof(double));	
		
		cx = (double*)malloc(n * sizeof(double));
		cy = (double*)malloc(m * sizeof(double));
		Calc_08();
		
		c2x = (double*)malloc(4*(n-1) * sizeof(double));
		c2y = (double*)malloc(4*(m-1) * sizeof(double));
		Calc_30();
			
		ym1 = (double*)malloc(nn * sizeof(double));
		yym1 = (double*)malloc(nnn * sizeof(double));
		ym2 = (double*)malloc(nn * sizeof(double));
		yym2 = (double*)malloc(nnn * sizeof(double));
		glLineWidth(0.6f);
		qglColor ("green");
		glBegin(GL_LINES);
		for (i = 0; i < nn; i++) {
			ym1[i] = value(n, x, xz[i], cx, 1);
			ym2[i] = value(n, xxx, xz[i], c2x, 2);
		}
		for (i = 0; i < nnn; i++) {
			yym1[i] = value(m, xx, yxz[i], cy, 1);
			yym2[i] = value(m, yyy, yxz[i], c2y, 2);
		}
		for (i = 0; i < nn; i++) {
			z[i*nnn] = ym1[i] + yym1[0];
			for (j = 1; j < nnn; j++) {
				z[i*nnn + j] = ym1[i] + yym1[j];
				glVertex3f (xz[i], yxz[j-1], z[i*nnn+j-1]); glVertex3f (xz[i], yxz[j], z[i*nnn+j]);
			}
		}
		glLineWidth(0.6f);
		qglColor ("blue");
		glBegin(GL_LINES);
		for (i = 0; i < nn; i++) {
			z2[i*nnn] = ym2[i] + yym2[0];
			for (j = 1; j < nnn; j++) {
				z2[i*nnn + j] = ym2[i] + yym2[j];
				glVertex3f (xz[i], yxz[j-1], z2[i*nnn+j-1]); glVertex3f (xz[i], yxz[j], z2[i*nnn+j]);
			}
		}
		for (i = 0; i < nn; i++){
			for (j = 0; j < nnn; j++) {
				z1 = fabs(Z[i*nnn+j] - z[i*nnn + j]);
				if (z1 > error1) error1 = z1;
				z1 = fabs(Z[i*nnn+j] - z2[i*nnn + j]);
				if (z1 > error2) error2 = z1;
			}
		}
		drawFunc();
		glEnd();	
		free(x);
		free(xx);
		free (cx);
		free (cy);
		free(xxx);
		free(yyy);		
		free(c2x);
		free(c2y);		
		free (z);
		free (ym1);
		free (yym1);
		free (z2);
		free (ym2);
		free (yym2);
	}
	else{
		double z1 = 0, z3 = 0;
		glLineWidth(0.6f);
		qglColor ("green");
		glBegin(GL_LINES);
		z = (double*)malloc(nn * nnn * sizeof(double));	
		z2 = (double*)malloc(nn * nnn * sizeof(double));	
		
		cx = (double*)malloc(n * sizeof(double));
		cy = (double*)malloc(m * sizeof(double));
		Calc_08();
		
		c2x = (double*)malloc(4*(n-1) * sizeof(double));
		c2y = (double*)malloc(4*(m-1) * sizeof(double));
		Calc_30();
			
		ym1 = (double*)malloc(nn * sizeof(double));
		yym1 = (double*)malloc(nnn * sizeof(double));
		ym2 = (double*)malloc(nn * sizeof(double));
		yym2 = (double*)malloc(nnn * sizeof(double));
		for (i = 0; i < nn; i++) {
			ym1[i] = value(n, x, xz[i], cx, 1);
			ym2[i] = value(n, xxx, xz[i], c2x, 2);
		}
		for (i = 0; i < nnn; i++) {
			yym1[i] = value(m, xx, yxz[i], cy, 1);
			yym2[i] = value(m, yyy, yxz[i], c2y, 2);
		}
		for (i = 0; i < nn; i++)
			for (j = 0; j < nnn; j++)
				z[i*nnn + j] = ym1[i] + yym1[j];
		for (i = 0; i < nn; i++)
			for (j = 0; j < nnn; j++)
				z2[i*nnn + j] = ym2[i] + yym2[j];
		for (i = 0; i < nn; i++){
			z1 = fabs (Z[i*nnn] - z[i*nnn]);
			if (z1 > error1) error1 = z1;			
			for (j = 1; j < nnn; j++) {
				z3 = fabs (Z[i*nnn+j] - z[i*nnn + j]);
				if (z3 > error1) error1 = z3;
				glVertex3f (xz[i], yxz[j-1], z1); 
				glVertex3f (xz[i], yxz[j], z3);				
			}
		}
		glLineWidth(0.6f);
		qglColor ("blue");
		glBegin(GL_LINES);
		for (i = 0; i < nn; i++){
			z1 = fabs (Z[i*nnn] - z2[i*nnn]);
			if (z1 > error2) error2 = z1;			
			for (j = 1; j < nnn; j++) {
				z3 = fabs (Z[i*nnn+j] - z2[i*nnn + j]);
				if (z3 > error2) error2 = z3;
				glVertex3f (xz[i], yxz[j-1], z1); 
				glVertex3f (xz[i], yxz[j], z3);				
			}
		}
		glEnd();
		free(x);
		free(xx);
		free (cx);
		free (cy);
		free(xxx);
		free(yyy);		
		free(c2x);
		free(c2y);		
		free (z);
		free (ym1);
		free (yym1);
		free (z2);
		free (ym2);
		free (yym2);
	}
	free(xz);
	free(yxz);
	free(Z);	
}
void Scene3D::drawFunc () {
	double x11, delx;
	double y2 = 0, dely;
	double z1 = 0, z22 = 0, z3 = 0, z4 = 0;
	double x_mid, y_mid;
	delx = (b - a) / width();
	dely = (d - c) / width();
	int nn =2, nnn = 2, i, j;
	for (x11 = a + delx; x11 - b < 1.e-6; x11 += delx) nn++;
	for (x11 = c + dely; x11 - d < 1.e-6; x11 += dely) nnn++;
	double *yxz2, *xz2, *ZZ;	
	yxz2 = (double*)malloc(nnn * sizeof(double));   		   		
	xz2 = (double*)malloc(nn * sizeof(double));	
	xz2[0] = a;
	yxz2[0] = c;
	for (i = 0; i < nn - 2; i++) {
		xz2[i+1] = xz2[i] + delx;
	}
	for (i = 0; i < nnn - 2; i++) {		
		yxz2[i+1] = yxz2[i] + dely;
	}		
	xz2[nn-1] = b;
	yxz2[nnn-1] = d;
	ZZ = (double*)malloc(nn * nnn * sizeof(double));		
	for (i = 0; i < nn; i++) {
		for (j = 0; j < nnn; j++)		
			ZZ[i*nnn + j] = f2(xz2[i], yxz2[j]);
	}
	x_mid = a + n / 2 * vh;
	y_mid = c + m / 2 * vg;
		glLineWidth(0.5f);
		qglColor ("black");
		glBegin(GL_LINES);
		for (i = 0; i < nn-1; i++) {
			z1 = ZZ[i*nnn];
			for (j = 1; j < nnn - 1; j++) {
				z22 = ZZ[i*nnn+j]; 
				z3 = ZZ[(i+1)*nnn+j]; 
				z4 = ZZ[(i+1)*nnn+(j-1)];;
				if (fabs (xz2[i+1] - x_mid) < 1.0e-10 && fabs (yxz2[j] - y_mid) < 1.0e-10)
				{
					z22 += 0.1 * outrage * max;
					z3 += 0.1 * outrage * max;
					z4 += 0.1 * outrage * max;
				}
				glVertex3f (xz2[i], yxz2[j-1], z1); glVertex3f (xz2[i], yxz2[j], z22);
				glVertex3f (xz2[i], yxz2[j-1], z1); glVertex3f (xz2[i+1], yxz2[j], z3);
				glVertex3f (xz2[i], yxz2[j-1], z1); glVertex3f (xz2[i+1], yxz2[j-1], z4);
				z1 = z22;
			}
			y2 = d;
			z22 = ZZ[(i+1)*nnn-1];
			glVertex3f (xz2[i], yxz2[nnn-2], z1); glVertex3f (xz2[i], y2, z22);
		}
		y2 = d;
		z1 = z22;
		glVertex3f (xz2[nn-2], yxz2[nnn-2], z1); glVertex3f (xz2[nn-1], y2, ZZ[nn*nnn-1]);
		glEnd();
	free(yxz2);
	free(xz2);
	free(ZZ);
}
double Scene3D::value(int l, double *x2, double t, double *cc, int fl){//, int fll){
	/*int i;
	if (fll == 1){
		if (t != b)
			i = (int)((t + delta_x - a) / vh);
		else
			i = l-2;
	}
	else{		
		if (t == c)
			i = 0;
		else if (t == d)
			i = l-2;
		else
			i = (int) ((t - c) / vg);
	}
	if (fl == 1){
		return cc[i] * (t - x2[i + 1])/(x2[i] - x2[i + 1]) + cc[i + 1] * (t - x2[i])/(x2[i + 1] - x2[i]);
	}
	else{
		return cc[4 * i] + cc[4 * i + 1] * (t - x2[i]) +
			cc[4 * i + 2] * (t - x2[i]) * (t - x2[i]) +
			cc[4 * i + 3] * (t - x2[i]) * (t - x2[i]) * (t - x2[i]);
	}*/

	int i;
	if (fl == 1){
		if (t < x2[1]) 
			return cc[0] * (t - x2[1])/(x2[0] - x2[1]) + cc[1] * (t - x2[0])/(x2[1] - x2[0]);
		for (i = 1; i < l - 2; i++)
			if (t <= x2[i + 1]) 
				return cc[i] * (t - x2[i + 1])/(x2[i] - x2[i + 1]) + cc[i + 1] * (t - x2[i])/(x2[i + 1] - x2[i]);
		return cc[l - 2] * (t - x2[l - 1])/(x2[l - 2] - x2[l - 1]) + cc[l - 1] * (t - x2[l - 2])/(x2[l - 1] - x2[l - 2]);
	}
	else{
		for (i = 0; i < l - 2; i++) 
			if (t <= x2[i + 1]) 
				break;
		return cc[4 * i] + cc[4 * i + 1] * (t - x2[i]) +
			cc[4 * i + 2] * (t - x2[i]) * (t - x2[i]) +
			cc[4 * i + 3] * (t - x2[i]) * (t - x2[i]) * (t - x2[i]);
	}
}
void Scene3D::increase_n () {
	n *= 2;
	N *= 2;
	update ();
}
void Scene3D::reduce_n () {
	if (n != 2 && n != 3) {
		n /= 2;
		N /= 2;
		update ();
	}
}
void Scene3D::zoom_in()
{
	a /= 2;
	b /= 2;
	c /= 2;
	d /= 2;
	update();
}
void Scene3D::zoom_out()
{
	if (func_id == 5 && (b > 150 || d > 150)){
		printf("Ошибка! Превышение!\n");
		update();
	}
	else{
		a *= 2;
		b *= 2;
		c *= 2;
		d *= 2;
		update();
	}
}
void Scene3D::increase_m () {
	m *= 2;
	M *= 2;
	update ();
}
void Scene3D::reduce_m () {
	if (m != 2 && m != 3) {
		m /= 2;
		M /= 2;
		update ();
	}
}
void Scene3D::plus() {
	outrage++;
	update ();
}
void Scene3D::minus() {
	outrage--;
	update ();
}
void Scene3D::change_mode () {
	mode = (mode + 1) % 4;
	switch (mode)
	{
	case 0:
		f_name_2 = "8 method";
		break;
	case 1:
		f_name_2 = "30 method";
		break;
	case 2:
		f_name_2 = "two method";
		break;
	case 3:
		f_name_2 = "ошибка/погрешность";
		break;

	}
	update ();
}
void Scene3D::initializeGL() { 
   qglClearColor(Qt::white);
   glEnable(GL_DEPTH_TEST);  
   glShadeModel(GL_FLAT);    
   glEnable(GL_CULL_FACE);  
   glEnableClientState(GL_VERTEX_ARRAY); 
   glEnableClientState(GL_COLOR_ARRAY);  
}
void Scene3D::resizeGL(int nWidth, int nHeight) { 
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity();            
   GLfloat ratio=(GLfloat)nHeight/(GLfloat)nWidth; 
   if (nWidth>=nHeight)
      glOrtho(-1.0/ratio, 1.0/ratio, -1.0, 1.0, -10.0, 1.0); 
   else
      glOrtho(-1.0, 1.0, -1.0*ratio, 1.0*ratio, -10.0, 1.0);      
   glViewport(0, 0, (GLint)nWidth, (GLint)nHeight);
}
void Scene3D::paintGL() { 
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
   glMatrixMode(GL_MODELVIEW); 
   glLoadIdentity();           
   glScalef(nSca, nSca, nSca);       
   glTranslatef(0.0f, zTra, 0.0f);    
   glRotatef(xRot, 1.0f, 0.0f, 0.0f);      
   glRotatef(yRot, 0.0f, 1.0f, 0.0f); 
   glRotatef(zRot, 0.0f, 0.0f, 1.0f); 
   char k[128];
  
   glViewport(150, 0, 900, 900);
   qglColor ("purple");
   renderText(5, 60, f_name);
   sprintf(k, "k = %d", func_id);
   renderText(5, 80, k);
   renderText(5, 100, f_name_2);

  sprintf(k, "отрезок [a,b] = [%.2lf,", a);
  renderText (5, 120, k);
  sprintf(k, "%.2lf]", b);
  renderText (175, 120, k);
  sprintf(k, "отрезок [c,d] = [%.2lf,", c);
  renderText (5, 140, k);
  sprintf(k, "%.2lf]", d);
  renderText (175, 140, k);

  sprintf(k, "n = %d", n);
  renderText (5, 160, k);
  sprintf(k, "m = %d", m);
  renderText (5, 180, k);

  sprintf(k, "p = %d", outrage);
  renderText (5, 200, k);
  if(mode != 3)
  {
	sprintf(k, "max = %lf", max);
  	renderText (5, 220, k);
  }

  if(mode != 1)
  {
	  qglColor ("blue");
	   sprintf(k, "ошибка 8-го = %le", error1);
	  renderText (5, 280, k);

  }
  if(mode != 0)
  {
	   qglColor ("blue");
	   sprintf(k, "ошибка 30-го = %le", error2);
	  renderText (5, 300, k);

  }
   PaintEvent();
}  
void Scene3D::mousePressEvent(QMouseEvent* pe) { //мышка
   ptrMousePosition = pe->pos();  
} 
void Scene3D::mouseMoveEvent(QMouseEvent* pe) { //мышка
   xRot += 180/nSca*(GLfloat)(pe->y()-ptrMousePosition.y())/height(); 
   zRot += 180/nSca*(GLfloat)(pe->x()-ptrMousePosition.x())/width(); 
   ptrMousePosition = pe->pos();
   updateGL(); 
}
void Scene3D::wheelEvent(QWheelEvent* pe) { // мышка
   if ((pe->delta())>0) scale_plus(); else if ((pe->delta())<0) scale_minus();   
   updateGL();        
}
void Scene3D::keyPressEvent(QKeyEvent* pe) { 
	switch (pe->key()) {
		case Qt::Key_Plus:
			scale_plus();     // приблизить сцену
		break;

		case Qt::Key_Equal:
			scale_plus();     // приблизить сцену
		break;

		case Qt::Key_Minus:
			scale_minus();    // удалиться от сцены
		break;

		case Qt::Key_Up:
			rotate_up();      // повернуть сцену вверх
		break;

		case Qt::Key_Down:
			rotate_down();    // повернуть сцену вниз
		break;

		case Qt::Key_Left:
			rotate_left();     // повернуть сцену влево
		break;

		case Qt::Key_Right:
			rotate_right();   // повернуть сцену вправо
		break;

		case Qt::Key_Z:
			translate_down(); // транслировать сцену вниз
		break;

		case Qt::Key_X:
			translate_up();   // транслировать сцену вверх
		break;

		case Qt::Key_Space:  
			defaultScene();   // возвращение значений по умолчанию

		break;

		case Qt::Key_Escape: 
			this->close();    // завершает приложение
		break;

		case Qt::Key_0:
			change_func ();
		break;

		case Qt::Key_1:
			change_mode ();
		break;

		case Qt::Key_2:
			increase_n ();
		break;

		case Qt::Key_3:
			reduce_n ();
		break;

		case Qt::Key_4:
			increase_m ();
		break;

		case Qt::Key_5:
			reduce_m ();
		break;

		case Qt::Key_6:
			plus ();
		break;

		case Qt::Key_7:
			minus ();
		break;
		case Qt::Key_8:
			zoom_in ();
		break;

		case Qt::Key_9:
			zoom_out ();
		break;
	}

	updateGL();
}
void Scene3D::scale_plus() {
   nSca = nSca*1.1;
}
void Scene3D::scale_minus() { 
   nSca = nSca/1.1;
}
void Scene3D::rotate_up() { 
   xRot += 1.0;
}
void Scene3D::rotate_down() {
   xRot -= 1.0;
}
void Scene3D::rotate_left() { 
   zRot += 1.0;
}
void Scene3D::rotate_right() { 
   zRot -= 1.0;
}
void Scene3D::translate_down() { 
   zTra -= 0.05;
}
void Scene3D::translate_up() {
   zTra += 0.05;
}
void Scene3D::defaultScene() { 
   xRot=-90; yRot=0; zRot=0; zTra=0; nSca=1;
}
